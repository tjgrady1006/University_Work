/**
 * 
 */

/**
 * @author Thomas Grady
 *
 */
public class TriangleSolver {
	/**
	 * 
	 * @param t
	 * @return
	 */
	public String solveTriangle(Triangle t) {	//single line comment
		
		float a = t.getA();
		float b = t.getB();
		float c = t.getC();
		
		if (areEqual(a,b) && areEqual(a,c)) {
			return "Equilateral";
		}
		
		else if (areEqual(a,b) && !areEqual(b,c) || areEqual(a,c) && !areEqual(b,c)) {
			return "Isosceles";
		}
		else if (!areEqual(a,b) && !areEqual(a,c) && !areEqual(b,c)) {
			return "Scalene";
		}
		else {
			return "Not a Triangle";
		}
		
	}
	/**
	 * 
	 * @param a
	 * @param b
	 * @return
	 */
	public boolean areEqual(float a, float b) {		//single line comment
		
		int state = Float.compare(a, b);
		if (state == 0) {
			return true;
		}
		else {
			return false;
		}		
	}
}
