/**
 * 
 */

/**
 * @author Thomas Grady
 *
 */
public class Triangle {
	
	private float a = 0.0f;		//single line comment
	
	private float b = 0.0f;		//single line comment
	
	private float c = 0.0f;		//single line comment
/**
 * 
 * @param sa
 * @param sb
 * @param sc
 */
	public Triangle(float sa, float sb, float sc) {
		/**
		 * Multiline comment
		 */
		this.a = sa;
				
		this.b = sb;
		
		this.c = sc;
	}

	/**
	 * @return getting the value for a
	 */
	public float getA() {
		return a;		 //single line comment
	}

	/**
	 * @param setting the value for a
	 */
	public void setA(float sa) {
		this.a = sa;		//single line comment
	}

	/**
	 * @return the b
	 */
	public float getB() {
		return b; 		//single line comment
	}

	/**
	 * @param b the b to set
	 */
	public void setB(float sb) {
		this.b = sb;		//single line comment
	}

	/**
	 * @return the c
	 */
	public float getC() {
		return c;		//single line comment
	}

	/**
	 * @param c the c to set
	 */
	public void setC(float sc) {
		this.c = sc;		//single line comment
	}
	
	/**
	 * 
	 * 
	 * Multiline comment
	 */
}
